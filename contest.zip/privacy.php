<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">

<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

<title>Privacy Policy</title>


</head>
<body>

<center><br /><br /><br /><br /><br /><br /><br />
<H1>Privacy Policy</H1>

This Application takes your privacy seriously. This policy describes what information we collect and how we use it and protect it. By using this application, you are indicating that you agree with the policy and consent to our use of your information as outlined here. As we may update this policy periodically, you should review it for changes.
</p>
<p></p>
<p>
<H1>Activity Logging</H1>

As you use this Application, we do not record data about how this application is used, including your operating system and version, your browser and version, your IP address, your preferred language, how much time you spend on each page, etc.
</p>
</center>



</body>
</html>